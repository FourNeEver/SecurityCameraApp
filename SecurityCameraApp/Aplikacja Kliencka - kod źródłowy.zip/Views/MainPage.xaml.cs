﻿using System.Net.WebSockets;

namespace SecurityCameraApp;

public partial class MainPage : ContentPage
{
	int count = 0;

	public MainPage()
	{
		InitializeComponent();

	}

}

